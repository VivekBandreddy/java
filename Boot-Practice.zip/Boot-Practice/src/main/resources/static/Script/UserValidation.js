function formValidation(){
	
	var userName=document.myForm.userName.value;
	var password=document.myForm.password.value; 
	
	
	if(!userName){
		document.getElementById("userName").innerHTML="User Name is Required";
		return false;
	}	else{
		document.getElementById("userName").innerHTML="";
	}
	
	if(!password){
		document.getElementById("password").innerHTML="Password is Required";
		return false;
	}else{
		document.getElementById("password").innerHTML="";
	}
	
	if(userName.length<=4){
		document.getElementById("userName").innerHTML="User Name Must be 5 Characters";
		return false;
	}else{
		document.getElementById("userName").innerHTML="";
	}
	
	if(password.length<=5){
		document.getElementById("password").innerHTML="Password Must be 6 Characters";
		return false;
	}else{
		document.getElementById("password").innerHTML="";
	}
	
	return true;
}

function removeWarning() {
    document.getElementById(this.id + "_error").innerHTML = "";
}

document.getElementById("userName").onkeyup=removeWarning;
document.getElementById("password").onkeyup=removeWarning;
