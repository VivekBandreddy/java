package com.example.demo.constants;

public class BootPracticeConstants {
	
	public final static String ROLLNUMBER="rollNumber";
	public final static String FIRSTNAME="firstName";
	public final static String LASTNAME="lastName";
	public final static String USERNAME="userName";
	public final static String LASTLOGINDATE="lastLoginDate";
	public static final String USERTYPE="userType";
	public final static String SESSIONID="sessionId";
	public final static String UserSessionCookie="SessionCookie";
	
	
	/**
	 * View Page Names
	 */
	public final static String LOGINPAGE="Login";

}
