package com.example.demo.pojo;

public class PasswordForm {

	private String userName;
	private String password;
	private String confirmPassword;
	private String rollNumber;
	
	
	public PasswordForm() {
		super();
	}


	public PasswordForm(String userName, String password, String confirmPassword, String rollNumber) {
		super();
		this.userName = userName;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.rollNumber = rollNumber;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getConfirmPassword() {
		return confirmPassword;
	}


	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}


	public String getRollNumber() {
		return rollNumber;
	}


	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}
	
	
}
