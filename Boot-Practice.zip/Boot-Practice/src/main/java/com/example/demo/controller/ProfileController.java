package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.bo.BootPracticeBO;
import com.example.demo.constants.BootPracticeConstants;
import com.example.demo.pojo.UserDetailsTEO;

import freemarker.template.utility.StringUtil;


@Controller
public class ProfileController {
	
	@Autowired
	BootPracticeBO bootPracticeBO;
	
	private static final Logger log=LoggerFactory.getLogger(ProfileController.class);
	
	@RequestMapping("/profile")
	public ModelAndView loadProfile(HttpServletRequest request,HttpServletResponse response) {
		
		log.info("Inside profile");
		
		HttpSession session=request.getSession();
		
		ModelAndView modelAndView=new ModelAndView();
		
		String rollNumber=(String) session.getAttribute(BootPracticeConstants.ROLLNUMBER);
		String dolc=(String) session.getAttribute(BootPracticeConstants.LASTLOGINDATE);
		String userTpye=(String) session.getAttribute(BootPracticeConstants.USERTYPE);
		log.info("Roll Number is {}",rollNumber);
		UserDetailsTEO userDetailsTEO=bootPracticeBO.getuserData(rollNumber);
		if(!StringUtils.isEmpty(userDetailsTEO)) {
			modelAndView.addObject("userDetails", userDetailsTEO);
			modelAndView.setViewName("profile");
			
			session.setAttribute(BootPracticeConstants.FIRSTNAME, userDetailsTEO.getFirstName());
		}
		
		/**modelAndView.addObject(BootPracticeConstants.ROLLNUMBER, rollNumber);
		modelAndView.addObject(BootPracticeConstants.LASTLOGINDATE, dolc);
		modelAndView.addObject(BootPracticeConstants.USERTYPE, userTpye);**/
		
		return modelAndView;
		
	}

}
