package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootPractceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootPractceApplication.class, args);
	}
}
