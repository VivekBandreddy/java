package com.example.demo.eo;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.constants.BootPracticeConstants;
import com.example.demo.pojo.PasswordForm;
import com.example.demo.pojo.StudentMarks;
import com.example.demo.pojo.UserDetailsTEO;
import com.example.demo.pojo.UserLoginStatusTEO;
import com.example.demo.pojo.UserLoginTEO;

@Component
public class BootPracticeEO {
	
	private RestTemplate restTemplate=new RestTemplate();
	
	@Value("${service.url}")
	private String url;
	
	public static final Logger log=LoggerFactory.getLogger(BootPracticeEO.class);
	
	public UserLoginStatusTEO userLogin(UserLoginTEO userLogin) {
		
		final String methodName="userLogin";
		UserLoginStatusTEO userLoginStatusTEO=new UserLoginStatusTEO();
		
		String uri=url+"Login";
		
		log.info("Calling rest template url for method {} {} ",methodName,uri);
		try {
			userLoginStatusTEO=restTemplate.postForObject(uri, userLogin, UserLoginStatusTEO.class);
			log.info("{}",userLoginStatusTEO.toString());
		}catch(Exception e) {
			log.error("Exception Details {}", e);
		}
		return   userLoginStatusTEO;
	}
	
	public UserDetailsTEO getuserDetails(String rollNumber) {
		
		final String methodName="getuserDetails";
		UserDetailsTEO userDetailsTEO=new UserDetailsTEO();
		userDetailsTEO.setRollNUmber(rollNumber);
		String uri=url+"UserDetails";
		
		Map<String, String> map=new HashMap<String,String>();
		map.put(BootPracticeConstants.ROLLNUMBER, rollNumber);
		
		log.info("Calling rest template url for method {} {} ",methodName,uri);
		try {
			userDetailsTEO=restTemplate.postForObject(uri, userDetailsTEO, UserDetailsTEO.class);
			log.info("{}",userDetailsTEO.toString());
		}catch(Exception e) {
			log.error("Exception Details {}", e);
		}
		return userDetailsTEO;
	}
	
	public StudentMarks getStudentMarks(String rollNumber) {
		final String methodName="getStudentMarks";
		log.debug("Inside Method {} for Roll NUmber {} ",methodName,rollNumber);	
		
		StudentMarks studentMarks=null;
		String uri=url+"StudentMarks?rollNumber="+rollNumber;
		log.info("Calling rest template url {} ",uri);
		try {
			studentMarks=restTemplate.getForObject(uri, StudentMarks.class);
		}catch(Exception e) {
			log.error("Exception details inside method {}",e);
		}
		return studentMarks;
	}

	public boolean updatePassword(PasswordForm passwordForm) {
		boolean flag=false;
		log.info("Calling rest template url {} ",url);
		try {
			flag=restTemplate.postForObject(url+"passwordUpdate", passwordForm, Boolean.class);
		}catch(Exception e) {
			log.error("Exception details inside method {}",e);
		}
		return flag;
	}
	
	public boolean isSAthenticatedUser(UserLoginStatusTEO userLoginStatusTEO) {
		boolean flag=false;
		
		log.info("Calling rest template url {} ",url);
		try {
			flag=restTemplate.postForObject(url+"sessionValidation", userLoginStatusTEO, Boolean.class);
		}catch (Exception e) {
			log.error("Exception Details {}", e);
		}
		return flag;
	}
	
	public boolean deleteUserSession(UserLoginStatusTEO userLoginStatusTEO) {
		boolean flag = false;
		String uri=url+"deleteSession";
		log.info("Calling rest template url {} ",uri);
		try {
			flag=restTemplate.postForObject(uri, userLoginStatusTEO, Boolean.class);
		}catch(Exception e) {
			log.error("Exception Details {}", e);
		}
		return flag;
	}

}
