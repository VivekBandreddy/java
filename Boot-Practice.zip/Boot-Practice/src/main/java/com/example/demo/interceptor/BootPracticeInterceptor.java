package com.example.demo.interceptor;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.WebUtils;

import com.example.demo.bo.BootPracticeBO;
import com.example.demo.constants.BootPracticeConstants;

@Component
public class BootPracticeInterceptor extends HandlerInterceptorAdapter {
	
	private static final Logger log=LoggerFactory.getLogger(BootPracticeInterceptor.class);
	private static final String COOKIE_NAME=BootPracticeConstants.UserSessionCookie;
	
	@Autowired
	private BootPracticeBO bootPracticeBO;
	
	@Override
	public boolean preHandle(HttpServletRequest request,HttpServletResponse response,Object object) throws IOException  {
		
		HttpSession session=null;
		session=request.getSession();
		String rollNumber=(String) session.getAttribute(BootPracticeConstants.ROLLNUMBER);
		boolean isValidRequest=true;
		log.info("Inside Interceptor");
		
		Cookie sessionCookie=WebUtils.getCookie(request, COOKIE_NAME);
		String sessionID=sesssionId(sessionCookie);
		
		if(StringUtils.isEmpty(sessionID)||StringUtils.isEmpty(rollNumber)) {
			log.info("Invalid Request");
			isValidRequest=false;
			returnHomePage(response);
			return isValidRequest;
		}
		isValidRequest=bootPracticeBO.isSAthenticatedUser(sessionID, rollNumber);
		log.info("Return Value {}",isValidRequest);
		return isValidRequest;
	}
	
	private String sesssionId(Cookie cookie) {
		String sessionID=cookie.getValue();
		return sessionID;
	}
	
	private void returnHomePage(HttpServletResponse response) throws IOException {
		
		response.sendRedirect("/invalidlogin");
	}
	
}
