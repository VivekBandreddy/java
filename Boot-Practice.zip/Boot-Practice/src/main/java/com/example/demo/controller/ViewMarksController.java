package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.bo.BootPracticeBO;
import com.example.demo.constants.BootPracticeConstants;
import com.example.demo.pojo.StudentMarks;

@Controller
public class ViewMarksController {
	
	@Autowired
	private BootPracticeBO bootPracticeBO;
	
	private static final Logger log=LoggerFactory.getLogger(ViewMarksController.class);
	
	@GetMapping("/marks")
	public ModelAndView viewMarksOnload(HttpServletRequest request) {
		
		final String methodName="viewMarksOnload";
		HttpSession session=request.getSession();
		log.info("{} starts",methodName);
		
		String rollNumber=(String) session.getAttribute(BootPracticeConstants.ROLLNUMBER);
		log.info("Roll Number {}",rollNumber);
		if(StringUtils.isEmpty(rollNumber)) {
			return new ModelAndView("Tech_Diff");
		}
		
		StudentMarks studentMarks=bootPracticeBO.getStudentMarks(rollNumber);
		
		return new ModelAndView("Marks","studentMarks",studentMarks);
	}

}
