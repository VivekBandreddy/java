package com.example.demo.pojo;

import java.io.Serializable;

public class StudentMaks_I_II implements Serializable {
	
	private String rollNumber;
	private int english_II;
	private int Maths_II;
	private int Engineering_Drawing;
	private int Environmental_Science;
	private int Physics_II;
	private int Chemistry_II;
	private int English_II_Lab;
	private int Physics_II_Lab;
	private int Chemistry_II_Lab;
	private String response;
	
	public StudentMaks_I_II() {
		super();
	}

	public StudentMaks_I_II(String rollNumber, int english_II, int maths_II, int engineering_Drawing,
			int environmental_Science, int physics_II, int chemistry_II, int english_II_Lab, int physics_II_Lab,
			int chemistry_II_Lab) {
		super();
		this.rollNumber = rollNumber;
		this.english_II = english_II;
		Maths_II = maths_II;
		Engineering_Drawing = engineering_Drawing;
		Environmental_Science = environmental_Science;
		Physics_II = physics_II;
		Chemistry_II = chemistry_II;
		English_II_Lab = english_II_Lab;
		Physics_II_Lab = physics_II_Lab;
		Chemistry_II_Lab = chemistry_II_Lab;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public int getEnglish_II() {
		return english_II;
	}

	public void setEnglish_II(int english_II) {
		this.english_II = english_II;
	}

	public int getMaths_II() {
		return Maths_II;
	}

	public void setMaths_II(int maths_II) {
		Maths_II = maths_II;
	}

	public int getEngineering_Drawing() {
		return Engineering_Drawing;
	}

	public void setEngineering_Drawing(int engineering_Drawing) {
		Engineering_Drawing = engineering_Drawing;
	}

	public int getEnvironmental_Science() {
		return Environmental_Science;
	}

	public void setEnvironmental_Science(int environmental_Science) {
		Environmental_Science = environmental_Science;
	}

	public int getPhysics_II() {
		return Physics_II;
	}

	public void setPhysics_II(int physics_II) {
		Physics_II = physics_II;
	}

	public int getChemistry_II() {
		return Chemistry_II;
	}

	public void setChemistry_II(int chemistry_II) {
		Chemistry_II = chemistry_II;
	}

	public int getEnglish_II_Lab() {
		return English_II_Lab;
	}

	public void setEnglish_II_Lab(int english_II_Lab) {
		English_II_Lab = english_II_Lab;
	}

	public int getPhysics_II_Lab() {
		return Physics_II_Lab;
	}

	public void setPhysics_II_Lab(int physics_II_Lab) {
		Physics_II_Lab = physics_II_Lab;
	}

	public int getChemistry_II_Lab() {
		return Chemistry_II_Lab;
	}

	public void setChemistry_II_Lab(int chemistry_II_Lab) {
		Chemistry_II_Lab = chemistry_II_Lab;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
}
