package com.example.demo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.example.demo.interceptor.BootPracticeInterceptor;

@Configuration
public class BootPracticeConfig extends WebMvcConfigurerAdapter {
	
	private static final Logger log=LoggerFactory.getLogger(BootPracticeConfig.class);
	
	private BootPracticeInterceptor bootInterceptor;
	
	public  BootPracticeConfig(BootPracticeInterceptor bootInterceptor) {
		log.info("Interceptor Initialized");
		this.bootInterceptor=bootInterceptor;
	}
	
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		log.info("interceptor added");
		//registry.addInterceptor(bootInterceptor).excludePathPatterns("/Practice/**/");
		
		//registry.addInterceptor(bootInterceptor).addPathPatterns("/Practice/UserLogin");
	}

}
