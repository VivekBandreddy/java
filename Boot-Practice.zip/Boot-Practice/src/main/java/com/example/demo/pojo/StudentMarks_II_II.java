package com.example.demo.pojo;

import java.io.Serializable;

public class StudentMarks_II_II  implements  Serializable{
	
	private String rollNumber;
	private int Java_Programming;
	private int DBMS;
	private int FLAT;
	private int Computer_Organization;
	private int PPL;
	private int Software_Engineering;
	private int Java_Programming_Lab;
	private int DBMS_Lab;
	private int English_Lab;
	
	public StudentMarks_II_II() {
		super();
	}

	public StudentMarks_II_II(String rollNumber, int java_Programming, int dBMS, int fLAT, int computer_Organization,
			int pPL, int software_Engineering, int java_Programming_Lab, int dBMS_Lab, int english_Lab) {
		super();
		this.rollNumber = rollNumber;
		Java_Programming = java_Programming;
		DBMS = dBMS;
		FLAT = fLAT;
		Computer_Organization = computer_Organization;
		PPL = pPL;
		Software_Engineering = software_Engineering;
		Java_Programming_Lab = java_Programming_Lab;
		DBMS_Lab = dBMS_Lab;
		English_Lab = english_Lab;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public int getJava_Programming() {
		return Java_Programming;
	}

	public void setJava_Programming(int java_Programming) {
		Java_Programming = java_Programming;
	}

	public int getDBMS() {
		return DBMS;
	}

	public void setDBMS(int dBMS) {
		DBMS = dBMS;
	}

	public int getFLAT() {
		return FLAT;
	}

	public void setFLAT(int fLAT) {
		FLAT = fLAT;
	}

	public int getComputer_Organization() {
		return Computer_Organization;
	}

	public void setComputer_Organization(int computer_Organization) {
		Computer_Organization = computer_Organization;
	}

	public int getPPL() {
		return PPL;
	}

	public void setPPL(int pPL) {
		PPL = pPL;
	}

	public int getSoftware_Engineering() {
		return Software_Engineering;
	}

	public void setSoftware_Engineering(int software_Engineering) {
		Software_Engineering = software_Engineering;
	}

	public int getJava_Programming_Lab() {
		return Java_Programming_Lab;
	}

	public void setJava_Programming_Lab(int java_Programming_Lab) {
		Java_Programming_Lab = java_Programming_Lab;
	}

	public int getDBMS_Lab() {
		return DBMS_Lab;
	}

	public void setDBMS_Lab(int dBMS_Lab) {
		DBMS_Lab = dBMS_Lab;
	}

	public int getEnglish_Lab() {
		return English_Lab;
	}

	public void setEnglish_Lab(int english_Lab) {
		English_Lab = english_Lab;
	}
	
}
