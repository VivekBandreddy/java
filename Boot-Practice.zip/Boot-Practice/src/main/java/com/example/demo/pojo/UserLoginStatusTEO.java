package com.example.demo.pojo;

import java.io.Serializable;

public class UserLoginStatusTEO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5930049010176577056L;
	private String userName;
	private String userType;
	private String rollNumber;
	private String userStatus;
	private String error;
	private String sessionId;
	private int loginAttempts;
	
	private UserDetailsTEO userDetails;
	private UserInteractionTEO userInteractionTEO;
	
	public UserLoginStatusTEO() {
		super();
	}

	public UserLoginStatusTEO(String userName, String userType, String rollNumber, String userStatus, String firstName,
			String middleName, String lastName, String sessionId,int loginAttempts,String error,UserDetailsTEO userDetails,UserInteractionTEO userInteractionTEO) {
		super();
		this.userName = userName;
		this.userType = userType;
		this.rollNumber = rollNumber;
		this.userStatus = userStatus;
		this.error=error;
		this.sessionId=sessionId;
		this.loginAttempts = loginAttempts;
		this.userInteractionTEO=userInteractionTEO;
		this.userDetails=userDetails;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public int getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(int loginAttempts) {
		this.loginAttempts = loginAttempts;
	}
	
	public UserInteractionTEO getUserInteractionTEO() {
		return userInteractionTEO;
	}

	public void setUserInteractionTEO(UserInteractionTEO userInteractionTEO) {
		this.userInteractionTEO = userInteractionTEO;
	}

	public UserDetailsTEO getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetailsTEO userDetails) {
		this.userDetails = userDetails;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
	
}
