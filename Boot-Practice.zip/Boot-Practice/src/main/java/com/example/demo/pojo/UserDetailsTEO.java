package com.example.demo.pojo;

import java.io.Serializable;

public class UserDetailsTEO implements Serializable {
	
	private String firstName;
	private String middleName;
	private String lastName;
	private long mobileNumber;
	private String email;
	private String rollNUmber;
	private String pursuingState;
	
	public UserDetailsTEO() {
		super();
	}

	public UserDetailsTEO(String firstName,String middleName, String lastName, long mobileNumber, String email, String rollNUmber,
			String pursuingState) {
		super();
		this.firstName = firstName;
		this.middleName=middleName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.rollNUmber = rollNUmber;
		this.pursuingState = pursuingState;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRollNUmber() {
		return rollNUmber;
	}

	public void setRollNUmber(String rollNUmber) {
		this.rollNUmber = rollNUmber;
	}

	public String getPursuingState() {
		return pursuingState;
	}

	public void setPursuingState(String pursuingState) {
		this.pursuingState = pursuingState;
	}
}
