package com.example.demo.pojo;

import java.io.Serializable;

public class StudentMarks_II_I implements Serializable {

	private String rollNumber;
	private int Data_Structures;
	private int MFCS;
	private int EDC;
	private int Digital_Logical_Design;
	private int MEFA;
	private int Probability_Statistics;
	private int Data_Structures_Lab;
	private int EDC_Lab;
	private int English_Lab;
	
	public StudentMarks_II_I() {
		super();
	}

	public StudentMarks_II_I(String rollNumber, int data_Structures, int mFCS, int eDC, int digital_Logical_Design,
			int mEFA, int probability_Statistics, int data_Structures_Lab, int eDC_Lab, int english_Lab) {
		super();
		this.rollNumber = rollNumber;
		Data_Structures = data_Structures;
		MFCS = mFCS;
		EDC = eDC;
		Digital_Logical_Design = digital_Logical_Design;
		MEFA = mEFA;
		Probability_Statistics = probability_Statistics;
		Data_Structures_Lab = data_Structures_Lab;
		EDC_Lab = eDC_Lab;
		English_Lab = english_Lab;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public int getData_Structures() {
		return Data_Structures;
	}

	public void setData_Structures(int data_Structures) {
		Data_Structures = data_Structures;
	}

	public int getMFCS() {
		return MFCS;
	}

	public void setMFCS(int mFCS) {
		MFCS = mFCS;
	}

	public int getEDC() {
		return EDC;
	}

	public void setEDC(int eDC) {
		EDC = eDC;
	}

	public int getDigital_Logical_Design() {
		return Digital_Logical_Design;
	}

	public void setDigital_Logical_Design(int digital_Logical_Design) {
		Digital_Logical_Design = digital_Logical_Design;
	}

	public int getMEFA() {
		return MEFA;
	}

	public void setMEFA(int mEFA) {
		MEFA = mEFA;
	}

	public int getProbability_Statistics() {
		return Probability_Statistics;
	}

	public void setProbability_Statistics(int probability_Statistics) {
		Probability_Statistics = probability_Statistics;
	}

	public int getData_Structures_Lab() {
		return Data_Structures_Lab;
	}

	public void setData_Structures_Lab(int data_Structures_Lab) {
		Data_Structures_Lab = data_Structures_Lab;
	}

	public int getEDC_Lab() {
		return EDC_Lab;
	}

	public void setEDC_Lab(int eDC_Lab) {
		EDC_Lab = eDC_Lab;
	}

	public int getEnglish_Lab() {
		return English_Lab;
	}

	public void setEnglish_Lab(int english_Lab) {
		English_Lab = english_Lab;
	}
	
}
