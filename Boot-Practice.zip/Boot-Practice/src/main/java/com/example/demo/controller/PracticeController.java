package com.example.demo.controller;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import com.example.demo.bo.BootPracticeBO;
import com.example.demo.constants.BootPracticeConstants;
import com.example.demo.pojo.UserLoginStatusTEO;
import com.example.demo.pojo.UserLoginTEO;


@Controller
public class PracticeController {
	
	@Autowired
	private BootPracticeBO bootPracticeBO;

	private static final Logger log=LoggerFactory.getLogger(PracticeController.class);
	private static final String INVALIDCREDENTIALS="IncorrectCredentials";
	private static final String SESSIONEXISTS="SessionExists";
	
	@GetMapping("/login")
	public String login(HttpServletRequest request) {
		return BootPracticeConstants.LOGINPAGE;
	}
	
	@PostMapping("/UserLogin")
	public void loadHomePage(@ModelAttribute UserLoginTEO userLoginTEO, 
			HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		HttpSession session=request.getSession();
		UserLoginStatusTEO userLoginStatusTEO;	
		
		if(StringUtils.isEmpty(userLoginTEO)) {
			response.sendRedirect("/login");
		}
		
		userLoginStatusTEO=bootPracticeBO.userLogin(userLoginTEO);
		
		//if(!StringUtils.isEmpty(userLoginStatusTEO.getRollNumber()))
		if(userLoginStatusTEO.getUserType().equalsIgnoreCase("S")){
			log.info("valid user {}  redirecting to user profile",userLoginStatusTEO.getUserName());
			
			session.setAttribute(BootPracticeConstants.USERNAME, userLoginStatusTEO.getUserName());
			session.setAttribute(BootPracticeConstants.ROLLNUMBER, userLoginStatusTEO.getRollNumber());
			session.setAttribute(BootPracticeConstants.SESSIONID,userLoginStatusTEO.getSessionId());
			session.setAttribute(BootPracticeConstants.USERTYPE, userLoginStatusTEO.getUserType());
			session.setAttribute(BootPracticeConstants.LASTNAME, userLoginStatusTEO.getUserInteractionTEO().getLastName());
			session.setAttribute(BootPracticeConstants.LASTLOGINDATE, userLoginStatusTEO.getUserInteractionTEO().getLoginDate());
			
			response.sendRedirect("/Practice/profile");
		}
		
	}
	
	@GetMapping("/logout")
	public String logout(HttpServletRequest request,HttpServletResponse response) {
		boolean flag=false;
		HttpSession session=request.getSession();
		String rollNumber=(String) session.getAttribute(BootPracticeConstants.ROLLNUMBER);
		Cookie cookie=WebUtils.getCookie(request, BootPracticeConstants.UserSessionCookie);
		String sessionid=cookie.getValue();
		flag=bootPracticeBO.deleteSession(sessionid, rollNumber);
		if(flag) {
			
			session.invalidate();
			log.info("Session Invalidated");
			request.setAttribute("status","logout");
			return BootPracticeConstants.LOGINPAGE;
		}
		return null;
	}
	
	private Cookie createCookie(String name,String value) {
		log.info("Creating cookie with name {} and value {}",name,value);
		Cookie cookie=new Cookie(name, value);
		cookie.setHttpOnly(true);
		cookie.setPath("/");
		cookie.setMaxAge(0);
		return cookie;

	}
}
