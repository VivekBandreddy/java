package com.example.demo.bo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.eo.BootPracticeEO;
import com.example.demo.pojo.PasswordForm;
import com.example.demo.pojo.StudentMarks;
import com.example.demo.pojo.UserDetailsTEO;
import com.example.demo.pojo.UserLoginStatusTEO;
import com.example.demo.pojo.UserLoginTEO;

@Component
public class BootPracticeBO {

	@Autowired
	BootPracticeEO bootPracticeEO;

	private static final Logger log = LoggerFactory.getLogger(BootPracticeBO.class);

	public UserLoginStatusTEO userLogin(UserLoginTEO userLogin) {
		UserLoginStatusTEO userLoginStatusTEO = new UserLoginStatusTEO();
		userLoginStatusTEO = bootPracticeEO.userLogin(userLogin);
		log.info("Exiting userlogin in BO");
		return userLoginStatusTEO;
	}
	
	public UserDetailsTEO getuserData(String rollNumber) {
		return bootPracticeEO.getuserDetails(rollNumber);
	}
	
	public StudentMarks getStudentMarks(String rollNumber) {
		return bootPracticeEO.getStudentMarks(rollNumber);
	}
	
	public boolean updatepassword(PasswordForm passwordForm) {
		return bootPracticeEO.updatePassword(passwordForm);
	}
	
	public boolean isSAthenticatedUser(String sessionId,String rollNumber) {
		UserLoginStatusTEO userLoginStatusTEO = new UserLoginStatusTEO();
		userLoginStatusTEO.setSessionId(sessionId);
		userLoginStatusTEO.setRollNumber(rollNumber);
		return bootPracticeEO.isSAthenticatedUser(userLoginStatusTEO);
	}
	
	public boolean deleteSession(String sessionId,String rollNumber) {
		UserLoginStatusTEO userLoginStatusTEO = new UserLoginStatusTEO();
		userLoginStatusTEO.setSessionId(sessionId);
		userLoginStatusTEO.setRollNumber(rollNumber);
		return bootPracticeEO.deleteUserSession(userLoginStatusTEO);
	}


}
