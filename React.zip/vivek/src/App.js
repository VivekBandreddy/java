import React from 'react';
import {Form, FormGroup, Label, Input} from 'reactstrap';
import './App.css';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


class App extends React.Component {

  state = {
    appNames: [],
    token: ''
  }

  componentDidMount(){
    fetch('/bank/jwt')
    .then((res) => res.json())
    .then((data) => this.setState({appNames: data}))
    .catch((error) => toast.error(error, "Something went wrong"))
  }

  getRSToken = (e) => {
    let appName = e.target.value;
    if(appName === '--'){
      toast.error('Please select one application name');
    }
    else {
        fetch(`/bank/jwt/token/${appName}`)
      .then((res) => res.json())
      .then((data) => this.setState({token: data}))
      .catch((error) => toast.error(error || 'Something went wrong'))
      }
  }

  render(){
  return (
    <div className="App">
      <Form>
        <FormGroup>
          <Label htmlFor='exampleSelect'>Application Name:  </Label>
          <Input type='select' name='select' id='exampleSelect' onChange={this.getRSToken}>
            <option>--</option>
            {this.state.appNames && this.state.appNames.map(name => <option>{name}</option>)}
          </Input>
        </FormGroup>
        <br/>
        <br/>
        <FormGroup>
          <Label htmlFor='exampleText'>RS256 Token: </Label>
          <Input type='textarea' name='text' id='exampleText' value={this.state.token}/>
        </FormGroup>
      </Form>
    </div>
  )};
}

export default App;
