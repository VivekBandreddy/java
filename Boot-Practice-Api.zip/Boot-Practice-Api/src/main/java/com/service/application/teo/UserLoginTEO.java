package com.service.application.teo;

import java.io.Serializable;

public class UserLoginTEO implements Serializable{
	
	private String userName;
	private String password;
	private String channelCode;
	private String ipAddress;
	
	public UserLoginTEO() {
		super();
	}

	public UserLoginTEO(String userName, String password, String channelCode, String ipAddress) {
		super();
		this.userName = userName;
		this.password = password;
		this.channelCode = channelCode;
		this.ipAddress = ipAddress;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
}
