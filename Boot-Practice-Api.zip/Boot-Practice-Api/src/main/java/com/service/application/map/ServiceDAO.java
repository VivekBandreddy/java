package com.service.application.map;

import java.util.ArrayList;
import java.util.List;

import com.service.application.teo.UserLoginStatusTEO;

public class ServiceDAO {
	
	List<UserLoginStatusTEO> userLoginStatus=new ArrayList<UserLoginStatusTEO>();
	
	public void add() {
		userLoginStatus.add(null);
	}
	

}
