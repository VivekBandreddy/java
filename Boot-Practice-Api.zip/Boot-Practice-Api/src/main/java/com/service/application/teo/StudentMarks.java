package com.service.application.teo;

public class StudentMarks {
	
	private StudentMaks_I_I studentMaks_I_I;
	private StudentMaks_I_II studentMaks_I_II;
	private StudentMarks_II_I studentMarks_II_I;
	private StudentMarks_II_II studentMarks_II_II;
	
	
	public StudentMarks() {
		super();
	}


	public StudentMarks(StudentMaks_I_I studentMaks_I_I, StudentMaks_I_II studentMaks_I_II,
			StudentMarks_II_I studentMarks_II_I, StudentMarks_II_II studentMarks_II_II) {
		super();
		this.studentMaks_I_I = studentMaks_I_I;
		this.studentMaks_I_II = studentMaks_I_II;
		this.studentMarks_II_I = studentMarks_II_I;
		this.studentMarks_II_II = studentMarks_II_II;
	}


	public StudentMaks_I_I getStudentMaks_I_I() {
		return studentMaks_I_I;
	}


	public void setStudentMaks_I_I(StudentMaks_I_I studentMaks_I_I) {
		this.studentMaks_I_I = studentMaks_I_I;
	}


	public StudentMaks_I_II getStudentMaks_I_II() {
		return studentMaks_I_II;
	}


	public void setStudentMaks_I_II(StudentMaks_I_II studentMaks_I_II) {
		this.studentMaks_I_II = studentMaks_I_II;
	}


	public StudentMarks_II_I getStudentMarks_II_I() {
		return studentMarks_II_I;
	}


	public void setStudentMarks_II_I(StudentMarks_II_I studentMarks_II_I) {
		this.studentMarks_II_I = studentMarks_II_I;
	}


	public StudentMarks_II_II getStudentMarks_II_II() {
		return studentMarks_II_II;
	}


	public void setStudentMarks_II_II(StudentMarks_II_II studentMarks_II_II) {
		this.studentMarks_II_II = studentMarks_II_II;
	}
	
	
	
	

}
