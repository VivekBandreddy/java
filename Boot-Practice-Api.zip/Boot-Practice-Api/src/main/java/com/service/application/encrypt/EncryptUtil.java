package com.service.application.encrypt;

import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.service.application.constants.ServiceConstants;


@Component
public class EncryptUtil {
	
	private static final Logger log=LoggerFactory.getLogger(EncryptUtil.class);
	private static final String  ALGORITHMNAME="AES";
	private static final int  KEYSIZE=128;
	private static final String EXCEPTIONOCCURED="Exception Occured";
	
	public String encryptText(String plainText)  {
		
		try {
			final String methodName="encryptText";
			log.debug("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
			SecretKey secretKey=generateSecretKey();
			Cipher cipher=Cipher.getInstance(ALGORITHMNAME);
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			byte[] cipherText=cipher.doFinal(plainText.getBytes());
			return new Base64().encodeBase64String(cipherText);
		}catch (Exception e) {
			log.error(e.getMessage());
		}
		
		return EXCEPTIONOCCURED;
	}
	
	
	private SecretKey generateSecretKey() throws NoSuchAlgorithmException {
		
		final String methodName="generateSecretKey";
		log.debug("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		
		KeyGenerator keyGenerator=KeyGenerator.getInstance(ALGORITHMNAME);
		keyGenerator.init(KEYSIZE);
		SecretKey seckey=keyGenerator.generateKey();
		return seckey;
	}

}
