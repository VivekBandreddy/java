package com.service.application.teo;

import java.io.Serializable;

public class UserRegistrationTEO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;
	private String salt;
	private String userType;
	private String rollNumber;
	private String userStatus;
	private String error;
	private int loginAttempts;
	
	public UserRegistrationTEO() {
		super();
	}

	public UserRegistrationTEO(String userName, String password, String salt, String userType, String rollNumber,
			String userStatus, String error, int loginAttempts) {
		super();
		this.userName = userName;
		this.password = password;
		this.salt = salt;
		this.userType = userType;
		this.rollNumber = rollNumber;
		this.userStatus = userStatus;
		this.error = error;
		this.loginAttempts = loginAttempts;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public int getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(int loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
		
}
