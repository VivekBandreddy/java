package com.service.application.teo;

import java.io.Serializable;

public class PasswordTEO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5349488680863956682L;
	private String userName;
	private String password;
	private String confirmPassword;
	private String salt;
	
	public PasswordTEO() {
		super();
	}

	public PasswordTEO(String userName, String password,String confirmPassword, String salt) {
		super();
		this.userName = userName;
		this.password = password;
		this.confirmPassword=confirmPassword;
		this.salt = salt;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
}
