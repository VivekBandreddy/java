package com.service.application.teo;

import java.io.Serializable;

public class UserLoginStatusTEO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1397370010306118756L;
	private String userName;
	private String userType;
	private String rollNumber;
	private String userStatus;
	private String error;
	private String sessionId;
	private int loginAttempts;
	
	private UserDetailsTEO userDetails;
	private UserInteractionTEO userInteractionTEO;
	
	public UserLoginStatusTEO() {
		super();
	}

	public UserLoginStatusTEO(String userName, String userType, String rollNumber, String userStatus, String error,
			String sessionId, int loginAttempts, UserDetailsTEO userDetails, UserInteractionTEO userInteractionTEO) {
		super();
		this.userName = userName;
		this.userType = userType;
		this.rollNumber = rollNumber;
		this.userStatus = userStatus;
		this.error = error;
		this.sessionId = sessionId;
		this.loginAttempts = loginAttempts;
		this.userDetails = userDetails;
		this.userInteractionTEO = userInteractionTEO;
	}


	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public int getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(int loginAttempts) {
		this.loginAttempts = loginAttempts;
	}
	
	public UserInteractionTEO getUserInteractionTEO() {
		return userInteractionTEO;
	}

	public void setUserInteractionTEO(UserInteractionTEO userInteractionTEO) {
		this.userInteractionTEO = userInteractionTEO;
	}

	public UserDetailsTEO getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetailsTEO userDetails) {
		this.userDetails = userDetails;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	
	
}
