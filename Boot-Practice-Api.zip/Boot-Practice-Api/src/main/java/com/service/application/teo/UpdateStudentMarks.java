package com.service.application.teo;

import java.io.Serializable;

public class UpdateStudentMarks implements Serializable {
	
	private String rollNumber;
	private String subject;
	private int marks;
	private int sem;
	
	public UpdateStudentMarks() {
		super();
	}

	public UpdateStudentMarks(String rollNumber, String subject, int marks,int sem) {
		super();
		this.rollNumber = rollNumber;
		this.subject = subject;
		this.marks = marks;
		this.sem=sem;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public int getSem() {
		return sem;
	}

	public void setSem(int sem) {
		this.sem = sem;
	}
	
}
