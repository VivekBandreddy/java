package com.service.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootPractceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootPractceApiApplication.class, args);
	}
}
