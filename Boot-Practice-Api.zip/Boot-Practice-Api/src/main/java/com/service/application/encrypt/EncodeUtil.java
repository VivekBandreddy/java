package com.service.application.encrypt;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import com.service.application.constants.ServiceConstants;
import com.service.application.teo.PasswordTEO;

@Component
public class EncodeUtil {
	
	private static final String Algorithm_Name="SHA-256";
	private static final String Master_Salt="masterSalt";
	private static final String UTF_Format="UTF-8";
	
	private static final Logger log=org.slf4j.LoggerFactory.getLogger(EncodeUtil.class);
	
	public PasswordTEO encodeUserPassword(PasswordTEO password) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		
		final String methodName="encodeUserPassword";
		log.debug("{} {}  Begins",ServiceConstants.INSIDE_METHOD,methodName);
		
		PasswordTEO passwordTEO=new PasswordTEO();
		String salt=generateSalt();
		salt+=password.getUserName();
		log.debug("Salt Value {} ",salt);
		passwordTEO.setSalt(salt);
		passwordTEO.setPassword(password.getPassword());
		byte[] b=generateencodedPassword(passwordTEO);
		
		salt=encodeString(salt.getBytes());
		String encodedpassword=encodeString(b);
		passwordTEO.setPassword(encodedpassword);
		passwordTEO.setSalt(salt);
		return passwordTEO;
	}
	public String getUserPassword(PasswordTEO passwordTEO) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		final String methodName="getUserPassword";
		log.debug("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		passwordTEO.setSalt(decodeString(passwordTEO.getSalt().getBytes()));
		log.debug("Decoded Salt value {} ",passwordTEO.getSalt());
		byte[] b=generateencodedPassword(passwordTEO);
		return encodeString(b);
	}
	private byte[] generateencodedPassword(PasswordTEO passwordTEO) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		final String methodName="generate encodePassword";
		log.debug("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		MessageDigest messageDigest=MessageDigest.getInstance(Algorithm_Name);
		messageDigest.reset();
		messageDigest.update(Master_Salt.getBytes());
		messageDigest.update(passwordTEO.getSalt().getBytes());
		messageDigest.update(passwordTEO.getPassword().getBytes());
		byte[] input=messageDigest.digest(passwordTEO.getPassword().getBytes(UTF_Format));
		for(int i=0;i<1000;i++) {
			messageDigest.reset();
			input=messageDigest.digest(input);
		}
		log.debug("{} {}",ServiceConstants.EXITING_METHOD,methodName);
		return input;
	}
	
	private String generateSalt() {
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("ddMMyyyyhhmmss");
		return sdf.format(date);
	}
	
	private String encodeString(byte[] input) {
		log.debug("{} Encoding Begin",ServiceConstants.INSIDE_METHOD);
		return Base64.encodeBase64String(input) ;
	}
	
	private String decodeString(byte[] input) {
		log.debug("{} Decoding Begin",ServiceConstants.INSIDE_METHOD);
		byte b[]= Base64.decodeBase64(input);
		return new String(b);
	}

}
