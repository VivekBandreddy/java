package com.service.application.teo;

import java.io.Serializable;

public class UserInteractionTEO implements Serializable {
	
	private String rollNumber;
	private String lastName;
	private String updateUserInteraction;
	private String loginDate;
	
	public UserInteractionTEO() {
		super();
	}

	public UserInteractionTEO(String rollNumber, String lastName, String updateUserInteraction, String loginDate) {
		super();
		this.rollNumber = rollNumber;
		this.lastName = lastName;
		this.updateUserInteraction = updateUserInteraction;
		this.loginDate = loginDate;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUpdateUserInteraction() {
		return updateUserInteraction;
	}

	public void setUpdateUserInteraction(String updateUserInteraction) {
		this.updateUserInteraction = updateUserInteraction;
	}

	public String getLoginDate() {
		return loginDate;
	}

	public void setLoginDate(String loginDate) {
		this.loginDate = loginDate;
	}
}
