package com.service.application.teo;

import java.io.Serializable;

public class StudentMaks_I_I implements Serializable {
	
	private String rollNumber;
	private int english;
	private int Maths_1;
	private int Computer_Programming;
	private int MatheMatical_Methods;
	private int Physics_1;
	private int Chemistry_1;
	private int English_Lab;
	private int Computer_Programming_Lab;
	private int Physics_1_Lab;
	private int Chemistry_1_Lab;
	
	
	public StudentMaks_I_I() {
		super();
	}


	public StudentMaks_I_I(String rollNumber, int english, int maths_1, int computer_Programming,
			int matheMatical_Methods, int physics_1, int chemistry_1, int english_Lab, int computer_Programming_Lab,
			int physics_1_Lab, int chemistry_1_Lab) {
		super();
		this.rollNumber = rollNumber;
		this.english = english;
		Maths_1 = maths_1;
		Computer_Programming = computer_Programming;
		MatheMatical_Methods = matheMatical_Methods;
		Physics_1 = physics_1;
		Chemistry_1 = chemistry_1;
		English_Lab = english_Lab;
		Computer_Programming_Lab = computer_Programming_Lab;
		Physics_1_Lab = physics_1_Lab;
		Chemistry_1_Lab = chemistry_1_Lab;
	}


	public String getRollNumber() {
		return rollNumber;
	}


	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}


	public int getEnglish() {
		return english;
	}


	public void setEnglish(int english) {
		this.english = english;
	}


	public int getMaths_1() {
		return Maths_1;
	}


	public void setMaths_1(int maths_1) {
		Maths_1 = maths_1;
	}


	public int getComputer_Programming() {
		return Computer_Programming;
	}


	public void setComputer_Programming(int computer_Programming) {
		Computer_Programming = computer_Programming;
	}


	public int getMatheMatical_Methods() {
		return MatheMatical_Methods;
	}


	public void setMatheMatical_Methods(int matheMatical_Methods) {
		MatheMatical_Methods = matheMatical_Methods;
	}


	public int getPhysics_1() {
		return Physics_1;
	}


	public void setPhysics_1(int physics_1) {
		Physics_1 = physics_1;
	}


	public int getChemistry_1() {
		return Chemistry_1;
	}


	public void setChemistry_1(int chemistry_1) {
		Chemistry_1 = chemistry_1;
	}


	public int getEnglish_Lab() {
		return English_Lab;
	}


	public void setEnglish_Lab(int english_Lab) {
		English_Lab = english_Lab;
	}


	public int getComputer_Programming_Lab() {
		return Computer_Programming_Lab;
	}


	public void setComputer_Programming_Lab(int computer_Programming_Lab) {
		Computer_Programming_Lab = computer_Programming_Lab;
	}


	public int getPhysics_1_Lab() {
		return Physics_1_Lab;
	}


	public void setPhysics_1_Lab(int physics_1_Lab) {
		Physics_1_Lab = physics_1_Lab;
	}


	public int getChemistry_1_Lab() {
		return Chemistry_1_Lab;
	}


	public void setChemistry_1_Lab(int chemistry_1_Lab) {
		Chemistry_1_Lab = chemistry_1_Lab;
	}
	
	
}
