package com.service.application.eo;


import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.service.application.constants.ServiceConstants;
import com.service.application.encrypt.EncodeUtil;
import com.service.application.encrypt.EncryptUtil;
import com.service.application.exception.PracticeException;
import com.service.application.teo.PasswordTEO;
import com.service.application.teo.StudentMaks_I_I;
import com.service.application.teo.StudentMaks_I_II;
import com.service.application.teo.StudentMarks_II_I;
import com.service.application.teo.StudentMarks_II_II;
import com.service.application.teo.UpdateStudentMarks;
import com.service.application.teo.UserDetailsTEO;
import com.service.application.teo.UserInteractionTEO;
import com.service.application.teo.UserLoginStatusTEO;
import com.service.application.teo.UserLoginTEO;
import com.service.application.teo.UserRegistrationTEO;

@Component
public class ServiceEO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private EncryptUtil encryptUtil;
	
	@Autowired
	EncodeUtil encodeUtil;
	
	private String sqlQuery;

	private static final Logger log=LoggerFactory.getLogger(ServiceEO.class);

		@SuppressWarnings({"unchecked", "rawtypes" })
		public UserLoginStatusTEO ValidateUserLogin(UserLoginTEO userlogin) throws NoSuchAlgorithmException, UnsupportedEncodingException {
			
			final String methodName="ValidateUserLogin";
			log.info("{} {}", ServiceConstants.INSIDE_METHOD, methodName);
			
			UserLoginStatusTEO userLoginStatusTEO;
			UserRegistrationTEO userRegistrationTEO=null;
			PasswordTEO passwordTEO=new PasswordTEO();
			EncodeUtil encodeUtil=new EncodeUtil();
			String password=null;
			
			sqlQuery="select * from user_login where username=?";
			log.info("{} {} calling {} for DB call ",ServiceConstants.INSIDE_METHOD,methodName,ServiceConstants.prepareQuery);
			log.debug("Sql Query {}",sqlQuery);
			try {
				/*userLoginStatus=(UserLoginStatusTEO)jdbcTemplate.queryForObject(sqlQuery ,new Object[] {userlogin.getUserName()},
								new BeanPropertyRowMapper(UserLoginStatusTEO.class));*/
				userRegistrationTEO=(UserRegistrationTEO) jdbcTemplate.queryForObject(sqlQuery, new Object[] {userlogin.getUserName()},
										new BeanPropertyRowMapper(UserRegistrationTEO.class));
				
				log.debug("Response From Data Base {} ",userRegistrationTEO.toString());
			}catch(EmptyResultDataAccessException e) {
				log.info("Exception occured at {} Exception Details {} ",methodName,e.getMessage());
			}
			
			if(!StringUtils.isEmpty(userRegistrationTEO)) {
				
				passwordTEO.setPassword(userlogin.getPassword());
				passwordTEO.setSalt(userRegistrationTEO.getSalt());
				password=encodeUtil.getUserPassword(passwordTEO);
				log.debug("Password from DB {} ",userRegistrationTEO.getPassword());
				log.debug("User Password after encoding {} ",password);
				log.debug("Salt Value {} ",userRegistrationTEO.getSalt());
				
				if(password.equals(userRegistrationTEO.getPassword())) {
					log.info("{} {} User Authenticated user name : {}",ServiceConstants.INSIDE_METHOD,methodName,userRegistrationTEO.getUserName());
					userLoginStatusTEO=new UserLoginStatusTEO();
					userLoginStatusTEO.setUserName(userRegistrationTEO.getUserName());
					userLoginStatusTEO.setLoginAttempts(userRegistrationTEO.getLoginAttempts());
					userLoginStatusTEO.setRollNumber(userRegistrationTEO.getRollNumber());
					userLoginStatusTEO.setUserStatus(userRegistrationTEO.getUserStatus());
					userLoginStatusTEO.setUserType(userRegistrationTEO.getUserType());
					log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
					return userLoginStatusTEO;
				}
			}
			log.info("{} {} Invalid Credentials",ServiceConstants.EXITING_METHOD,methodName);
			
			userLoginStatusTEO = new UserLoginStatusTEO();
			userLoginStatusTEO.setError("Invalid Credentials");
			userLoginStatusTEO.setLoginAttempts(10);
			return userLoginStatusTEO;
		}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public UserDetailsTEO getUserDetails(String rollNumber) {
			final String methodName="getUserDetails";
			log.info("{} {}", ServiceConstants.INSIDE_METHOD, methodName);
			UserDetailsTEO userDetails=null;
			sqlQuery="select * from user_details where rollnumber=?";
			log.info("{} {} calling {} for DB call ",ServiceConstants.INSIDE_METHOD,methodName,ServiceConstants.prepareQuery);
			//sqlQuery=prepareQuery(sqlQuery, RollNumber);
			try {
				userDetails= (UserDetailsTEO) jdbcTemplate.queryForObject(sqlQuery,new Object[] {rollNumber}, new BeanPropertyRowMapper(UserDetailsTEO.class));
			}catch(EmptyResultDataAccessException e) {
				log.error("Exception occured at method {} Exception Details {}",methodName,e);
			}
			log.debug("Returning User Details for the Roll Number {} ",rollNumber);
			log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
			return userDetails;
		}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public UserInteractionTEO updateUserInteraction(UserInteractionTEO userInteraction) {
			final String methodName="updateUserInteraction";
			log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
			UserInteractionTEO userInteractionTEO=null;
			sqlQuery="select * from User_Interaction where rollNumber=? and lastname=?";
			log.info("{} {} calling {} for DB call ",ServiceConstants.INSIDE_METHOD,methodName,ServiceConstants.prepareQuery);
			//sqlQuery=prepareQuery(sqlQuery, userInteraction.getRollNumber(),"lastname" ,userInteraction.getLastName());
			log.debug("Query for UserInteraction {}",sqlQuery);
			try {
				userInteractionTEO=(UserInteractionTEO) jdbcTemplate.queryForObject(sqlQuery,new Object[] {userInteraction.getRollNumber(),userInteraction.getLastName()}, 
						new BeanPropertyRowMapper(UserInteractionTEO.class));
			}catch(EmptyResultDataAccessException e) {
				log.info("Exception occured at method {} exception details {}",methodName,e);
			}
			
			if("y".equalsIgnoreCase(userInteraction.getUpdateUserInteraction())) {
				log.info("updating userInteraction for user Last Name {}",userInteraction.getLastName());
				sqlQuery="update User_Interaction set loginDate=? where rollNumber=? and lastName=? ";
				log.info("{} {} calling {} for DB call ",ServiceConstants.INSIDE_METHOD,methodName,ServiceConstants.prepareQuery);
				try {
					jdbcTemplate.update(sqlQuery,timeStamp(),userInteraction.getRollNumber(),userInteraction.getLastName());
					log.info("User Intercation Succesfull for user last name {}",userInteraction.getLastName());
				}catch(EmptyResultDataAccessException e) {
					log.info("Exception occured at method {} Exception details {}",methodName,e);
				}
			}
			log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
			return userInteractionTEO;
		}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public StudentMaks_I_I getStudentMaks_I_I(String rollNumber) {
			final String methodName="getStudentMaks_I_I";
			log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
			StudentMaks_I_I studentMaks_I_I=null;
			sqlQuery="select * from Student_Sem_Marks_I_I where rollnumber=?";
			//sqlQuery=prepareQuery(sqlQuery,rollNumber);
			log.debug("Sql Query {}",sqlQuery);
			try {
				studentMaks_I_I=(StudentMaks_I_I) jdbcTemplate.queryForObject(sqlQuery,new Object[] {rollNumber} ,new BeanPropertyRowMapper(StudentMaks_I_I.class));
			}catch(EmptyResultDataAccessException e) {
				log.info("Exception occured at method {} Exception Details {}",methodName,e);
			}
			log.debug("Returning User Details for the Roll Number {} ",rollNumber);
			log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
			return studentMaks_I_I;
		}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public StudentMaks_I_II getStudentMaks_I_II(String rollNumber) throws PracticeException {
			final String methodName="getStudentMaks_I_II";
			StudentMaks_I_II studentMaks_I_II=null;
			log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
			sqlQuery="select * from Student_Sem_Marks_I_II where rollnumber=?";
			//sqlQuery=prepareQuery(sqlQuery,rollNumber);
			log.debug("Sql Query {}",sqlQuery);
			try {
				studentMaks_I_II=(StudentMaks_I_II) jdbcTemplate.queryForObject(sqlQuery,new Object[] {rollNumber}, new BeanPropertyRowMapper(StudentMaks_I_II.class));
			}catch(EmptyResultDataAccessException e) {
				log.error("{}",e);
				throw new PracticeException("Student not available");
			}
			
			log.debug("Returning User Details for the Roll Number {} ",rollNumber);
			log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
			return studentMaks_I_II;
		}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public StudentMarks_II_I getStudentMaks_II_I(String rollNumber) {
			final String methodName="getStudentMaks_II_I";
			log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
			StudentMarks_II_I studentMaks_II_I=null;
			sqlQuery="select * from Student_Sem_Marks_II_I where rollnumber=?";
			//sqlQuery=prepareQuery(sqlQuery,rollNumber);
			log.debug("Sql Query {}",sqlQuery);
			try {
				studentMaks_II_I=(StudentMarks_II_I) jdbcTemplate.queryForObject(sqlQuery, new Object[] {rollNumber} ,new BeanPropertyRowMapper(StudentMarks_II_I.class));
			}catch(EmptyResultDataAccessException e) {
				log.info("Exception occured at method {} Exception Details {}",methodName,e);
			}
			log.debug("Returning User Details for the Roll Number {} ",rollNumber);
			log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
			return studentMaks_II_I;
		}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public StudentMarks_II_II getStudentMaks_II_II(String rollNumber) {
			final String methodName="getStudentMaks_II_II";
			log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
			StudentMarks_II_II studentMaks_II_II=null;
			sqlQuery="select * from Student_Sem_Marks_II_II where rollnumber=?";
			//sqlQuery=prepareQuery(sqlQuery,rollNumber);
			log.debug("Sql Query {}",sqlQuery);
			try {
				studentMaks_II_II=(StudentMarks_II_II) jdbcTemplate.queryForObject(sqlQuery,new Object[] {rollNumber} , new BeanPropertyRowMapper(StudentMarks_II_II.class));
			}catch(EmptyResultDataAccessException e) {
				log.info("Exception occured at method {} Exception details {}", methodName,e);
			}
			 
			log.debug("Returning User Details for the Roll Number {} ",rollNumber);
			log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
			return studentMaks_II_II;
		}
		
		//Updating Student Marks
		public int updateStudentMaks(UpdateStudentMarks updateStudentMarks) {
			final String methodName="updateStudentMaks_I_I";
			log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
			int i=0;
			//sqlQuery="update ? set ?=? where rollNumber=?";
			//String tableName=tableName(updateStudentMarks.getSem());
			sqlQuery=tableName(updateStudentMarks.getSem(),updateStudentMarks.getSubject());
			try {
				i=jdbcTemplate.update(sqlQuery,updateStudentMarks.getMarks(),updateStudentMarks.getRollNumber());
			}catch(EmptyResultDataAccessException e) {
				log.info("Exception occured at method {} Exception details {}",methodName,e);
			}
			log.info("{}",i);
			return i;
		}
		
		
		public String registerUser(UserRegistrationTEO userRegistrationTEO) throws NoSuchAlgorithmException, UnsupportedEncodingException {
			
			final String methodName="registerUser";
			log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
			
			UserRegistrationTEO userRegistration=new UserRegistrationTEO();
						
			log.debug("User Name {} Password {} ",userRegistrationTEO.getUserName(),userRegistrationTEO.getPassword());
			
			PasswordTEO password=new PasswordTEO();
			password.setUserName(userRegistrationTEO.getUserName());
			password.setPassword(userRegistrationTEO.getPassword());
			
			PasswordTEO passwordTEO=encodeUtil.encodeUserPassword(password);
			
			/**Preparing inputs for User Registration */
			userRegistration.setUserName(userRegistrationTEO.getUserName());
			userRegistration.setPassword(passwordTEO.getPassword());
			userRegistration.setSalt(passwordTEO.getSalt());
			userRegistration.setRollNumber(userRegistrationTEO.getRollNumber());
			userRegistration.setUserType(userRegistrationTEO.getUserType());
			userRegistration.setUserStatus("A");
			userRegistration.setLoginAttempts(0);
			
			sqlQuery="insert into user_login values(?,?,?,?,?,?,?)";
			int i=0;
			try {
				i=jdbcTemplate.update(sqlQuery,userRegistration.getUserName(),userRegistration.getPassword(),userRegistration.getSalt(),userRegistration.getUserType()
						,userRegistration.getRollNumber(),userRegistration.getUserStatus(),userRegistration.getLoginAttempts());
				if(i==1)
					return "User Registered";
			}catch (Exception e) {
				log.info("Exception occured at method {} Exception details {}",methodName,e);
			}
			return "Exception Occured while registering";
		}
		
		public boolean updatePassword(PasswordTEO passwordTEO) throws NoSuchAlgorithmException, UnsupportedEncodingException {
			final String methodName="updatePassword";
			int i=0;
			log.debug("{} {} updating user Password for user {} ",ServiceConstants.INSIDE_METHOD,methodName,passwordTEO.getUserName());
			PasswordTEO updatePasswordTEO=encodeUtil.encodeUserPassword(passwordTEO);
			if(StringUtils.isEmpty(updatePasswordTEO))
				return false;
			sqlQuery="update user_login set password=? , salt=? where username=? ";
			try {
				log.debug("password  {} salt {} userName {} ",updatePasswordTEO.getPassword(),updatePasswordTEO.getSalt(),passwordTEO.getUserName());
				i=jdbcTemplate.update(sqlQuery,updatePasswordTEO.getPassword(),updatePasswordTEO.getSalt(),passwordTEO.getUserName());
			}catch(Exception e) {
				log.info("Exception occured at method {} Exception details {}",methodName,e);
			}
			
			return i>0?true:false;
		}
		
		public boolean deleteUser(UserRegistrationTEO userRegistrationTEO) {
			final String methodName="deleteUser";
			int i=0;
			log.info("{} {} preparing for deleting user  {}",ServiceConstants.INSIDE_METHOD,methodName,userRegistrationTEO.getUserName());
			sqlQuery="delete from user_login where username=? and rollNumber=?";
			try {
				i=jdbcTemplate.update(sqlQuery,userRegistrationTEO.getUserName(),userRegistrationTEO.getRollNumber());
				log.info(" i {} ", i);
			}catch (EmptyResultDataAccessException e) {
				log.info("Exception at {} {} ",methodName,e);
			}
			return i>0?true:false;
		}
		
		public boolean isUserNameAvailable(String userName) {
			final String methodName="isUserNameAvailable";
			int i=0;
			log.info("{} {} checking userID availability {}",ServiceConstants.INSIDE_METHOD,methodName,userName);
			sqlQuery="select count(1) from user_login where username=?";
			try {
				i=jdbcTemplate.queryForObject(sqlQuery,new Object[] {userName},Integer.class);
				log.info(" i {} ", i);
			}catch(EmptyResultDataAccessException e) {
				log.info("{} {} user Id  {} is available",ServiceConstants.INSIDE_METHOD,methodName,userName);
			}
			return i>0?true:false;
		}
		
		public String CreateSession(String userName,String rollNumber) {
			
			int i;
			sqlQuery="insert into user_session values(?,?)";
			
			Random random=new Random();
			long randomNumber=random.nextLong();
			log.debug("Random Number Generated {} :" ,randomNumber);
			String plainText=userName+randomNumber;
			log.debug("plain text : {} ",plainText);
			String sessionId=encryptUtil.encryptText(plainText);
			log.info("Session Id : {} ",sessionId);
			if(!(StringUtils.isEmpty(sessionId)||(sessionId.equalsIgnoreCase("Exception Occured")))) {
				try {
					i=jdbcTemplate.update(sqlQuery,rollNumber,sessionId);
					if(i==1)
						return sessionId;
				}catch(Exception e) {
					log.error("Exception details {} ", e.getMessage());
					//return ServiceConstants.SESSIONEXISTS;
				}				
			}
			return sessionId;
		}
		
		public boolean isValidSession(String rollNumber,String sessionId) {
			final String methodName="validateSession";
			int i=0;
			log.info("{} {} validating session for  {}",ServiceConstants.INSIDE_METHOD,methodName,rollNumber);
			sqlQuery="select count(1) from user_session where rollNumber=? and sessionId=?";
			try {
				i=jdbcTemplate.queryForObject(sqlQuery,new Object[] {rollNumber,sessionId},Integer.class);
				log.info("{} {} i value {}",ServiceConstants.INSIDE_METHOD,methodName,i);
			}catch(EmptyResultDataAccessException e) {
				log.error("{} {} no session avilable for {}",ServiceConstants.INSIDE_METHOD,methodName,rollNumber);
			}
			return i>0?true:false;
		}
		
		public boolean deleteUserSession(String rollNumber,String sessionId) {
				
			final String methodName="deleteSession";
			int i=0;
			
			log.info("{} {} deleting user session for {} ",ServiceConstants.INSIDE_METHOD,methodName,rollNumber);
			sqlQuery="delete from user_session where rollnumber=? and sessionId=?";
			try {
				i=jdbcTemplate.update(sqlQuery,rollNumber,sessionId);
			}catch(Exception e) {
				log.error("Exception occured at {} exception details {}",methodName,e);
			}
			return i>0?true:false;
		}
		
		private String timeStamp() {
			Date date=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("MMM/dd/yyyy hh:mm a");
			return sdf.format(date)+" "+"IST";
		}
		
		private String tableName(int i,String subject) {
			int j=1;
			String[] tableNames= {"update Student_Sem_Marks_I_I set " +subject+ "=? where rollNumber=? ",
								  "update Student_Sem_Marks_I_II set " +subject+ "=? where rollNumber=?",
								  "update Student_Sem_Marks_II_I set " +subject+ "=? where rollNumber=?",
								  "update Student_Sem_Marks_II_II set " +subject+"=? where rollNumber=?"};
			for(String tableName:tableNames) {
				if(j==i) {
					log.info("Returning Table Name {} from method tableName",tableName);
					return tableName;
				}
				j++;
			}
			return null;
		}
}