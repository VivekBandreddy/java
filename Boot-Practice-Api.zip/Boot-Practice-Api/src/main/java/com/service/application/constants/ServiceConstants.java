package com.service.application.constants;

public class ServiceConstants {
	
	public static final String INSIDE_METHOD="Inside Method";
	public static final String EXITING_METHOD="Exiting Method";
	public static final String prepareQuery="prepareQuery";
	public static final String SESSIONEXISTS="Session Exists";

}
