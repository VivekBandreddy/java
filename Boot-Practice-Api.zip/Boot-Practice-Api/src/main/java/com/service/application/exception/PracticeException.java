package com.service.application.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PracticeException extends Exception {
	
	private static final long serialVersionUID = -6852082114980639209L;
	Logger log =  LoggerFactory.getLogger(PracticeException.class);
	private static String message;
	
	public PracticeException(){
		super();
	}
	
	public PracticeException(String message){
		super(message);
		this.message = message;
		log.error("Exception occured:"+message);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		PracticeException.message = message;
	}

}
