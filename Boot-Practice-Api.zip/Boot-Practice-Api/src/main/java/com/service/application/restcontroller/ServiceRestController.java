package com.service.application.restcontroller;


import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.service.application.bo.ServiceBO;
import com.service.application.constants.ServiceConstants;
import com.service.application.exception.PracticeException;
import com.service.application.teo.PasswordTEO;
import com.service.application.teo.StudentMaks_I_I;
import com.service.application.teo.StudentMaks_I_II;
import com.service.application.teo.StudentMarks;
import com.service.application.teo.StudentMarks_II_I;
import com.service.application.teo.StudentMarks_II_II;
import com.service.application.teo.UpdateStudentMarks;
import com.service.application.teo.UserDetailsTEO;
import com.service.application.teo.UserInteractionTEO;
import com.service.application.teo.UserLoginStatusTEO;
import com.service.application.teo.UserLoginTEO;
import com.service.application.teo.UserRegistrationTEO;


@RestController
public class ServiceRestController {
	
	 @Autowired
	private ServiceBO servicebo;
	
	private static final Logger log=LoggerFactory.getLogger(ServiceRestController.class);
	
	@PostMapping("/Login")
	public UserLoginStatusTEO validateUserLogin(@RequestBody UserLoginTEO userLogin) throws PracticeException, NoSuchAlgorithmException, UnsupportedEncodingException {
		
		final String methodName="validateUserLogin";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
		
		if(!(StringUtils.isEmpty(userLogin.getUserName())&&StringUtils.isEmpty(userLogin.getPassword()))) {
			log.info("user Name {}",userLogin.getUserName());
			log.debug("User password {}",userLogin.getPassword());
			return servicebo.validateUserLogin(userLogin);
			//log.info("{} {} ",ServiceConstants.EXITING_METHOD,methodName);
		}
		log.error("Invalid Inputs {} {} with response null",ServiceConstants.EXITING_METHOD,methodName);
		return null;
	}
	
	@PostMapping("/UserInteraction")
	public UserInteractionTEO updateUserInteraction(@RequestBody UserInteractionTEO userInteraction) {
		final String methodName="updateUserInteraction";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
		return servicebo.updateUserInteraction(userInteraction);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	@PostMapping("/UserDetails")
	public UserDetailsTEO getUserDetails(@RequestBody UserDetailsTEO userDetailsTEO) {
		final String methodname="getUserDetails";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodname);
		return servicebo.getUserDetails(userDetailsTEO.getRollNUmber());
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}

	@GetMapping("/I-I")
	public StudentMaks_I_I getStudentMaks_I_I(@RequestParam("rollNumber") String rollNumber) {
		
		//String rollNumber=
		final String methodname="getStudentMaks_I_I";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodname);
		return servicebo.getStudentMaks_I_I(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	@SuppressWarnings("null")
	@GetMapping("/I-II")
	public StudentMaks_I_II getStudentMaks_I_II(@RequestParam("rollNumber") String rollNumber) {
		final String methodname="getStudentMaks_I_II";
		StudentMaks_I_II response = null;
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodname);
		try {
			response = servicebo.getStudentMaks_I_II(rollNumber);
		} catch (PracticeException e) {
			response.setResponse(e.getMessage());
		}
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
		return response;
	}
	
	@GetMapping("/II-I")
	public StudentMarks_II_I getStudentMaks_II_I(@RequestParam("rollNumber") String rollNumber) {
		final String methodname="getStudentMaks_II_I";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodname);
		return servicebo.getStudentMaks_II_I(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	@GetMapping("/II-II")
	public StudentMarks_II_II getStudentMaks_II_II(@RequestParam("rollNumber") String rollNumber) {
		final String methodname="getStudentMaks_II_II";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodname);
		return servicebo.getStudentMaks_II_II(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	@GetMapping("/StudentMarks")
	public StudentMarks getStudentMarks(@RequestParam("rollNumber") String rollNumber) throws PracticeException {
		final String methodname="getStudentMarks";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodname);
		return servicebo.getAllMarksforStudent(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	@PostMapping("/updateStudentMarks")
	public String updateStudentMaks(@RequestBody UpdateStudentMarks updateStudentMarks) {
		final String methodName="updateStudentMaks";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
		if(!(StringUtils.isEmpty(updateStudentMarks))) {
			int i=servicebo.updateStudentMaks(updateStudentMarks);
			if(i==1) 
				return "Records Updated Succesfully for "+updateStudentMarks.getRollNumber();
		}
		throw new IllegalArgumentException("Required Fields Should Not Be Null");
	}
	
	@PostMapping("/passwordUpdate")
	public boolean UpdatePassword(@RequestBody PasswordTEO passwordTEO ) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		final String methodName="UpdatePassword";
		boolean flag=false;
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
		if(passwordTEO.getPassword().equals(passwordTEO.getConfirmPassword()))
			flag= servicebo.updatePassword(passwordTEO);
		log.info("{} {} ",ServiceConstants.EXITING_METHOD,methodName);		
		return flag;
	}
	
	@PostMapping("/register")
	public String registerUser(@RequestBody UserRegistrationTEO userRegistrationTEO) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		final String methodName="registerStudent";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
		if((!StringUtils.isEmpty(userRegistrationTEO.getUserName()))
				||(!StringUtils.isEmpty(userRegistrationTEO.getPassword()))
				||(!StringUtils.isEmpty(userRegistrationTEO.getRollNumber()))
				||(!StringUtils.isEmpty(userRegistrationTEO.getUserType()))) {
			
			log.info("{} calling BO layer for registerting user {}  ",ServiceConstants.INSIDE_METHOD,userRegistrationTEO.getUserName());
			return servicebo.registerUser(userRegistrationTEO);
		}
		throw new IllegalArgumentException("Required Fields Should Not Be Null");
	}
	
	@PostMapping("/delete")
	public String deleteUser(@RequestBody UserRegistrationTEO userRegistrationTEO) {
		
		final String methodName="deleteUser";
		log.info("{} {}",ServiceConstants.INSIDE_METHOD,methodName);
		
		return servicebo.deleteUser(userRegistrationTEO);
	}
	
	@PostMapping("/sessionValidation")
	public boolean isValidSession(@RequestBody UserLoginStatusTEO userLoginStatusTEO) {
		return servicebo.isvalidSession(userLoginStatusTEO.getRollNumber(), userLoginStatusTEO.getSessionId());
	}
	
	@PostMapping("/deleteSession")
	public boolean deleteUserSession(@RequestBody UserLoginStatusTEO userLoginStatusTEO) {
		return servicebo.deleteUserSession(userLoginStatusTEO.getRollNumber(), userLoginStatusTEO.getSessionId());
	}
	
}
