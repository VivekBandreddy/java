package com.service.application.bo;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.service.application.constants.ServiceConstants;
import com.service.application.eo.ServiceEO;
import com.service.application.exception.PracticeException;
import com.service.application.teo.PasswordTEO;
import com.service.application.teo.StudentMaks_I_I;
import com.service.application.teo.StudentMaks_I_II;
import com.service.application.teo.StudentMarks;
import com.service.application.teo.StudentMarks_II_I;
import com.service.application.teo.StudentMarks_II_II;
import com.service.application.teo.UpdateStudentMarks;
import com.service.application.teo.UserDetailsTEO;
import com.service.application.teo.UserInteractionTEO;
import com.service.application.teo.UserLoginStatusTEO;
import com.service.application.teo.UserLoginTEO;
import com.service.application.teo.UserRegistrationTEO;

@Component
public class ServiceBO {

	@Autowired
	private ServiceEO serviceEO;
	
	
	private static final Logger log=LoggerFactory.getLogger(ServiceBO.class);
	
	public UserLoginStatusTEO validateUserLogin(UserLoginTEO userLogin) throws PracticeException, NoSuchAlgorithmException, UnsupportedEncodingException {
		
		UserInteractionTEO userInteractionTEO=new UserInteractionTEO();
		UserLoginStatusTEO userLoginStatusTEO;
		UserDetailsTEO userDetailsTEO;
		String sessionId;
		final String methodName="validateUserLogin ";
		log.info("{} {} Service Call for User Validation User {} ",ServiceConstants.INSIDE_METHOD,methodName,userLogin.getUserName());
		
		userLoginStatusTEO= serviceEO.ValidateUserLogin(userLogin);
		if(userLoginStatusTEO==null) {
			userLoginStatusTEO=new UserLoginStatusTEO();
			log.info("User Credentials were Incorrect / No data found for user {}", userLogin.getUserName());
			userLoginStatusTEO.setError("Incorrect Credentials");
			return userLoginStatusTEO;
		}	
		
		
		if(!StringUtils.isEmpty(userLoginStatusTEO.getRollNumber())) {
			
			sessionId=serviceEO.CreateSession(userLoginStatusTEO.getUserName(), userLoginStatusTEO.getRollNumber());
			if(sessionId.equalsIgnoreCase(ServiceConstants.SESSIONEXISTS)){
				userLoginStatusTEO=new UserLoginStatusTEO();
				log.info("User Session Exists for user {}", userLogin.getUserName());
				userLoginStatusTEO.setError(ServiceConstants.SESSIONEXISTS);
				return userLoginStatusTEO;
			}
			userLoginStatusTEO.setSessionId(sessionId);
			
			log.info("Retriving user data for userid {}",userLogin.getUserName());
			userDetailsTEO=serviceEO.getUserDetails(userLoginStatusTEO.getRollNumber());
			if(!StringUtils.isEmpty(userDetailsTEO.getLastName())) {
				
				log.info("Calling Update User Interaction for user {} {}",userDetailsTEO.getFirstName(),userDetailsTEO.getLastName());
				userInteractionTEO.setRollNumber(userLoginStatusTEO.getRollNumber());
				log.info("Roll Number {}",userLoginStatusTEO.getRollNumber());
				userInteractionTEO.setLastName(userDetailsTEO.getLastName());
				userInteractionTEO.setUpdateUserInteraction("Y");
				userInteractionTEO=serviceEO.updateUserInteraction(userInteractionTEO);
				userInteractionTEO.setUpdateUserInteraction("Yes");
				userLoginStatusTEO.setUserInteractionTEO(userInteractionTEO);
			}
			userLoginStatusTEO.setUserDetails(userDetailsTEO);
		}
		log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
		return userLoginStatusTEO;
	}
	
	public UserInteractionTEO updateUserInteraction(UserInteractionTEO userInteraction) {
		final String methodName="updateUserInteraction";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		return serviceEO.updateUserInteraction(userInteraction);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	public UserDetailsTEO getUserDetails(String  RollNumber) {
		final String methodName="getUserDetails";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		return serviceEO.getUserDetails(RollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	public StudentMaks_I_I getStudentMaks_I_I(String rollNumber) {
		final String methodName="getStudentMaks_I_I";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		return serviceEO.getStudentMaks_I_I(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	public StudentMaks_I_II getStudentMaks_I_II(String rollNumber) throws PracticeException {
		final String methodName="getStudentMaks_I_II";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		return serviceEO.getStudentMaks_I_II(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	public StudentMarks_II_I getStudentMaks_II_I(String rollNumber) {
		final String methodName="getStudentMaks_II_I";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		return serviceEO.getStudentMaks_II_I(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	public StudentMarks_II_II getStudentMaks_II_II(String rollNumber) {
		final String methodName="getStudentMaks_II_II";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		return serviceEO.getStudentMaks_II_II(rollNumber);
		//log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
	}
	
	public StudentMarks getAllMarksforStudent(String rollNumber) throws PracticeException {
		
		final String methodName="getAllMarksforStudent";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		
		StudentMarks studentMarks=new StudentMarks();
		
		studentMarks.setStudentMaks_I_I(serviceEO.getStudentMaks_I_I(rollNumber));
		studentMarks.setStudentMaks_I_II(serviceEO.getStudentMaks_I_II(rollNumber));
		studentMarks.setStudentMarks_II_I(serviceEO.getStudentMaks_II_I(rollNumber));
		studentMarks.setStudentMarks_II_II(serviceEO.getStudentMaks_II_II(rollNumber));
		log.info("{} {}",ServiceConstants.EXITING_METHOD,methodName);
		return studentMarks;
	}
	
	public int updateStudentMaks(UpdateStudentMarks updateStudentMarks) {
		final String methodName="updateStudentMaks_I_I";
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		return serviceEO.updateStudentMaks(updateStudentMarks);
	}
	
	public String registerUser(UserRegistrationTEO userRegistrationTEO) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		
		final String methodName="registerStudents";
		boolean flag;
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		flag=isUserNameAvailable(userRegistrationTEO.getUserName());
		if(!flag) {
			return serviceEO.registerUser(userRegistrationTEO);
		}
		return "User Id Already Exists  "+userRegistrationTEO.getUserName(); 
	}
	
	public boolean updatePassword(PasswordTEO passwordTEO) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		return serviceEO.updatePassword(passwordTEO);
	}

	public String deleteUser(UserRegistrationTEO userRegistrationTEO) {
		final String methodName="registerStudents";
		boolean flag;
		log.info("{} {} ",ServiceConstants.INSIDE_METHOD,methodName);
		flag=isUserNameAvailable(userRegistrationTEO.getUserName());
		if(flag) {
			serviceEO.deleteUser(userRegistrationTEO);
			return "Record Deleted";
		}
		return "Please check the User Id";
	}
	
	public boolean isvalidSession(String rollNumber,String sessionId) {
		return serviceEO.isValidSession(rollNumber, sessionId);
	}
	
	public boolean deleteUserSession(String rollNumber,String sessionId) {
		return serviceEO.deleteUserSession(rollNumber, sessionId);
	}
	
	private boolean isUserNameAvailable(String userName) {
		
		return serviceEO.isUserNameAvailable(userName);
	}


}
